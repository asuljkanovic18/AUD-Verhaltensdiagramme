﻿using System;


//Console.WriteLine("Hello, World!");



namespace StatePatternDemo
{
    //'Client'
    class Program
    {
        
        static void Main(string[] args)
        {
            Player player = new Player();
            player.Bullethit(3);
            player.Bullethit(9);
            player.Bullethit(12);

            Console.ReadLine();
        }
    }
    // 'Context' class
    public class Player
    {
        State currentState;

        public Player()
        {
            this.currentState = new HealthyState();
        }

        public void Bullethit(int bullets)
        {
            Console.WriteLine("Spieler getroffen: " + bullets);
            if (bullets < 5)
                this.currentState = new HealthyState();
            if (bullets >= 5 && bullets < 10)
                this.currentState = new HurtState();
            if (bullets >= 10)
                this.currentState = new DeadState();

            currentState.ExecuteCommand(this);
        }
    }
    // 'State' interface
    public interface State
    {
        void ExecuteCommand(Player player);
    }
    // 'ConcreteStateA' class
    public class HealthyState : State
    {
        public void ExecuteCommand(Player player)
        {
            Console.WriteLine("Gesund");
        }
    }
    // 'ConcreteStateB' class
    public class HurtState : State
    {
        public void ExecuteCommand(Player player)
        {
            Console.WriteLine("Verwundet");
        }
    }
    // 'ConcreteStateC' class
    public class DeadState : State
    {
        public void ExecuteCommand(Player player)
        {
            Console.WriteLine("Tot");
        }
    }
}
﻿using System;


//Console.WriteLine("Hello, World!");



namespace StatePatternDemo
{
    //'Client'
    class Program
    {
        
        static void Main(string[] args)
        {
            Student student = new Student();
            student.ReachedPoints(95);
            student.ReachedPoints(91);
            student.ReachedPoints(77);
            student.ReachedPoints(57);
            student.ReachedPoints(9);

            Console.ReadLine();
        }
    }
    // 'Context' class
    public class Student
    {
        State currentState;

        public Student()
        {
            this.currentState = new GradeOne();
        }

        public void ReachedPoints(int points)
        {
            Console.WriteLine($"Student reached  {points} points");
            if (points < 91)
                this.currentState = new GradeOne();
            if (points >= 80 && points < 92)
                this.currentState = new GradeTwo();
            if (points >= 66 && points < 81)
                this.currentState = new GradeThree();
            if (points >= 50 && points < 66)
                this.currentState = new GradeFour();
            if (points >= 0 && points < 50)
                this.currentState = new GradeFive();

            currentState.ExecuteCommand(this);
        }
    }
    // 'State' interface
    public interface State
        
    {
        void ExecuteCommand(Student student);
    }
    // Grade 1
    public class GradeOne : State
    {
        public void ExecuteCommand(Student student)
        {
            Console.WriteLine("Grade: 1");
        }
    }
    // Grade 2
    public class GradeTwo : State
    {
        public void ExecuteCommand(Student student)
        {
            Console.WriteLine("Grade: 2");
        }
    }
    // Grade 3
    public class GradeThree : State
    {
        public void ExecuteCommand(Student student)
        {
            Console.WriteLine("Grade: 3");
        }
    }
    // Grade 4
    public class GradeFour : State
    {
        public void ExecuteCommand(Student student)
        {
            Console.WriteLine("Grade: 4");
        }
    }
    // Grade 5
    public class GradeFive : State
    {
        public void ExecuteCommand(Student student)
        {
            Console.WriteLine("Grade: 5");
        }
    }
}